# Curso Codo a Codo Fullstack 2024


# Equipo:

- Cristian Ferro
- Sebastián Cardozo
- Hugo Barreto
- Juan Pablo Alfonso

